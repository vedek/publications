## Welcome to Repository of Publications.

1. [./Fake Math]Fake Math Papers
2. [./Fake CompSci]Fake Computer Science Papers









## Contact
For more information, contact Dr Bheemaiah, Anil Kumar at bheemaiaha@yopmail.com
